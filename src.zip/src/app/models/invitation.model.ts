export interface InvitationData {
  graduateName: string;
  career: string;
  date: string;        // "Sábado, 15 de Noviembre 2026"
  time: string;         // "7:00 PM"
  venue: string;
  address: string;
  dressCode?: string;
  message: string;
  whatsappNumber: string; // "593987654321" (sin +)
  whatsappMessage: string;
  googleFormUrl?: string;
  mapsUrl: string;
  mapsEmbedUrl: string;
  galleryImages: string[];
}