import { InvitationData } from '../models/invitation.model';

export const INVITATION_DATA: InvitationData = {
  graduateName: 'María José Pérez',
  career: 'Ingeniería en Software',
  date: 'Sábado, 15 de Noviembre 2026',
  time: '7:00 PM',
  venue: 'Salón de Eventos Los Almendros',
  address: 'Av. Principal 123, Manabí, Ecuador',
  dressCode: 'Formal / Elegante',
  message: 'Con inmensa alegría te invito a celebrar este logro tan importante en mi vida. Tu presencia hará de este día algo inolvidable.',
  whatsappNumber: '593987654321',
  whatsappMessage: 'Hola! Confirmo mi asistencia a la graduación de María José 🎓',
  googleFormUrl: '',
  mapsUrl: 'https://maps.google.com/?q=...',
  mapsEmbedUrl: 'https://www.google.com/maps/embed?pb=...',
  galleryImages: [
    'assets/images/grad-photo.jpg',
    'assets/images/gallery/foto1.jpg',
    'assets/images/gallery/foto2.jpg'
  ]
};