import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Header as HeaderComponent } from './components/header/header';
import { Hero as HeroComponent } from './components/hero/hero';
import { Details as DetailsComponent } from './components/details/details';
import { Message as MessageComponent } from './components/message/message';
import { Gallery as GalleryComponent } from './components/gallery/gallery';
import { Location as LocationComponent } from './components/location/location';
import { Rsvp as RsvpComponent } from './components/rsvp/rsvp';
import { Footer as FooterComponent } from './components/footer/footer';
import { INVITATION_DATA } from './data/invitation-data';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    HeaderComponent, HeroComponent, DetailsComponent,
    MessageComponent, GalleryComponent, LocationComponent,
    RsvpComponent, FooterComponent, RouterOutlet
  ],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class AppComponent {
  data = INVITATION_DATA;
  readonly title = signal('Invitación de graduación');
}